int dividir(int);

int distintoACero(int);

int factorial(int);
