#include <stdio.h>
#include <stdlib.h>

#include "Biblioteca.h"

int main()
{
    saludar();
    return 0;
}
