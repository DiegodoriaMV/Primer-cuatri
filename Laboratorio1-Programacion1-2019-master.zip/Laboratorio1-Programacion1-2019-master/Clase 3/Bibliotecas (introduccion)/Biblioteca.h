int saludar();
