int cambiarValor(int);

int cambiarValorReferencia(int*);
