#include <stdio.h>
#include <stdlib.h>

int main()
{
    int edad= 66;
    float altura= 82.5;

    printf("\nEdad: \t Altura: \n");
    printf("%d %15f \n", edad, altura);

    return 0;
}
