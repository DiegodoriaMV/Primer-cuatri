#include <stdio.h>
#include <stdlib.h>

//prototipo
void saludar(void);

int main()
{
    saludar();
    return 0;
}

//Funcion implementada
void saludar(void)
{
    printf("Hello world! \n");
}
