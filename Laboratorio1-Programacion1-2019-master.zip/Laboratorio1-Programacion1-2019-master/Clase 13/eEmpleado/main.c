#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Empleado.h"


int main()
{

    /*********** TAREA ***********
    -COMPLETAR:
    -LLAMADAS A FUNCION.
    -ARRAY DE EMPLEADOS.
    -MOSTRAR EMPLEADOS.
    *******************************/

    return 0;
}
